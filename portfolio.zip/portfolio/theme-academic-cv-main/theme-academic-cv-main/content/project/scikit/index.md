---
title: scikit-learn
date: 2023-10-26
links:
  - type: site
    url: https://github.com/scikit-learn/scikit-learn
tags:
  - Hugo
  - HugoBlox
  - Markdown
---

scikit-learn is a Python module for machine learning built on top of SciPy and is distributed under the 3-Clause BSD license.

<!--more-->
